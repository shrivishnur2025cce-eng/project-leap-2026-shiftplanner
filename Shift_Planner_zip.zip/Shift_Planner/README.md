# ShiftPlanner – Employee Shift Roster & Swap Requests System

> **A Full-Stack Enterprise Grade Java Spring Boot & React Application for Automated Employee Shift Roster Management and Multi-Step Shift Swap Approvals.**

---

## 📌 Problem Statement & Objective
Small retail and manufacturing teams build weekly shift rosters manually on whiteboards or informal messaging channels. Swap requests between employees are tracked verbally, causing high error rates, shift overlaps, and attendance disputes.

**ShiftPlanner** solves this by providing:
1. **Automated Roster Scheduling**: Managers assign employees to shift slots while enforcing strict zero-overlap rules.
2. **Multi-Step Swap Workflow**: Employees initiate shift swaps that require **both** target colleague acceptance **and** manager final approval before any database roster changes occur.
3. **Real-time Dashboard & Weekly Grid**: Interactive visual schedule showing current assignments and swap request states.

---

## 🏗 System Architecture

```
                                  ┌────────────────────────┐
                                  │      React + Vite      │
                                  │   Frontend Dashboard   │
                                  └───────────┬────────────┘
                                              │ HTTP / JSON (Axios)
                                              ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                               Spring Boot 3 REST Backend                               │
│                                                                                        │
│  ┌──────────────────────┐    ┌──────────────────────┐    ┌──────────────────────────┐  │
│  │     Controllers      │───▶│   Service Layer      │───▶│   JpaRepositories        │  │
│  │ (Employee, Shift,    │    │ (Business Rules,     │    │ (Employee, Shift,        │  │
│  │  Roster, SwapReq)    │    │  Overlap Detection)  │    │  Roster, SwapRequest)    │  │
│  └──────────────────────┘    └──────────────────────┘    └────────────┬─────────────┘  │
└───────────────────────────────────────────────────────────────────────│────────────────┘
                                                                        ▼
                                                          ┌──────────────────────────┐
                                                          │   MySQL Relational DB    │
                                                          │  (shiftplanner database) │
                                                          └──────────────────────────┘
```

---

## 🗄 Database Design & Entity Relationships

```
┌──────────────────┐               ┌──────────────────┐               ┌──────────────────┐
│     Employee     │               │      Roster      │               │      Shift       │
├──────────────────┤               ├──────────────────┤               ├──────────────────┤
│ id (PK)          │1             *│ id (PK)          │*             1│ id (PK)          │
│ employee_code    │───────────────│ employee_id (FK) │───────────────│ shift_name       │
│ name             │               │ shift_id (FK)    │               │ shift_date       │
│ email            │               │ status           │               │ start_time       │
│ phone            │               │ assigned_at      │               │ end_time         │
│ role             │               └──────────────────┘               │ description      │
│ active           │                        │ 1                       └──────────────────┘
└────────┬─────────┘                        │
         │ 1                                │ *
         │                               ┌──┴───────────────┐
         ├──────────────────────────────▶│   SwapRequest    │
         │ (requester_id)                ├──────────────────┤
         │                               │ id (PK)          │
         │ 1                             │ requester_id(FK) │
         └──────────────────────────────▶│ target_id (FK)   │
           (target_employee_id)          │ roster_id (FK)   │
                                         │ reason           │
                                         │ status           │
                                         │ requested_at     │
                                         └──────────────────┘
```

---

## ⚡ Core Business Rules Enforced in Service Layer

1. **Shift Overlap Rule**: An employee cannot be assigned to two overlapping shifts on the same day.
   - **Formula**: `existing.startTime < new.endTime AND existing.endTime > new.startTime`
   - Rejects with `409 CONFLICT` and `ShiftOverlapException`.
2. **Dual-Approval Swap Workflow**:
   - Step 1: Requester creates swap request ➔ Status: `PENDING_COLLEAGUE`. (Roster remains unchanged).
   - Step 2: Target colleague accepts ➔ Status: `COLLEAGUE_ACCEPTED`. (Roster remains unchanged).
   - Step 3: Manager approves ➔ Status: `COMPLETED`. (Roster is updated atomically via `@Transactional`).

---

## 🚀 Quick Setup Instructions

### 1. Database Setup (MySQL)
Open MySQL Workbench or Command Line Client:
```sql
CREATE DATABASE shiftplanner;
```
Import `database/schema.sql` or let Hibernate auto-create tables.
Configure your MySQL password in `backend/src/main/resources/application.properties`:
```properties
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD
```

### 2. Backend Startup
```bash
cd backend
mvn spring-boot:run
```
- REST API Server runs on `http://localhost:8080`.
- Swagger Documentation: `http://localhost:8080/swagger-ui.html`

### 3. Frontend Startup
```bash
cd frontend
npm install
npm run dev
```
- React Application opens on `http://localhost:5173`.

---

## 🧪 Testing Instructions
Run JUnit 5 integration tests:
```bash
cd backend
mvn test
```

All 13 test cases covering shift overlap rejection, colleague acceptance/rejection, manager approval, and status transitions will execute automatically using an in-memory H2 database.
