-- =========================================================
-- SHIFTPLANNER DATABASE SCHEMA & SAMPLE DATA (MySQL)
-- =========================================================

CREATE DATABASE IF NOT EXISTS shiftplanner;
USE shiftplanner;

-- Drop tables if they exist (in reverse order of dependency)
DROP TABLE IF EXISTS swap_requests;
DROP TABLE IF EXISTS rosters;
DROP TABLE IF EXISTS shifts;
DROP TABLE IF EXISTS employees;

-- 1. Employee Table
CREATE TABLE employees (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    employee_code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    role VARCHAR(20) NOT NULL, -- 'EMPLOYEE', 'MANAGER'
    active BOOLEAN NOT NULL DEFAULT TRUE
);

-- 2. Shift Table
CREATE TABLE shifts (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    shift_name VARCHAR(100) NOT NULL,
    shift_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    description VARCHAR(255)
);

-- 3. Roster Table
CREATE TABLE rosters (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    shift_id BIGINT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ASSIGNED', -- 'ASSIGNED', 'SWAPPED', 'CANCELLED'
    assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_roster_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT fk_roster_shift FOREIGN KEY (shift_id) REFERENCES shifts(id) ON DELETE CASCADE
);

-- 4. SwapRequest Table
CREATE TABLE swap_requests (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    requester_id BIGINT NOT NULL,
    target_employee_id BIGINT NOT NULL,
    roster_id BIGINT NOT NULL,
    reason VARCHAR(255),
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING_COLLEAGUE', -- 'PENDING_COLLEAGUE', 'COLLEAGUE_ACCEPTED', 'COLLEAGUE_DECLINED', 'MANAGER_APPROVED', 'MANAGER_REJECTED', 'COMPLETED'
    requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    colleague_responded_at DATETIME,
    manager_approved_at DATETIME,
    CONSTRAINT fk_swap_requester FOREIGN KEY (requester_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT fk_swap_target FOREIGN KEY (target_employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT fk_swap_roster FOREIGN KEY (roster_id) REFERENCES rosters(id) ON DELETE CASCADE
);

-- =========================================================
-- INITIAL DEMO SAMPLE DATA
-- =========================================================

-- Insert Employees
INSERT INTO employees (id, employee_code, name, email, phone, role, active) VALUES
(1, 'EMP001', 'Arun', 'arun@shiftplanner.com', '9876543210', 'EMPLOYEE', true),
(2, 'EMP002', 'Bala', 'bala@shiftplanner.com', '9876543211', 'EMPLOYEE', true),
(3, 'EMP003', 'Priya', 'priya@shiftplanner.com', '9876543212', 'EMPLOYEE', true),
(4, 'EMP004', 'Divya', 'divya@shiftplanner.com', '9876543213', 'EMPLOYEE', true),
(5, 'MGR001', 'Manager Kumar', 'kumar@shiftplanner.com', '9876543214', 'MANAGER', true);

-- Insert Shifts for the Week (2026-10-05 to 2026-10-09)
INSERT INTO shifts (id, shift_name, shift_date, start_time, end_time, description) VALUES
(1, 'Monday Morning Assembly', '2026-10-05', '09:00:00', '13:00:00', 'Morning Retail Store Operations'),
(2, 'Monday Afternoon Shift', '2026-10-05', '14:00:00', '18:00:00', 'Afternoon Floor Management'),
(3, 'Tuesday Morning Assembly', '2026-10-06', '09:00:00', '13:00:00', 'Tuesday Store Opening'),
(4, 'Tuesday Afternoon Shift', '2026-10-06', '14:00:00', '18:00:00', 'Tuesday Floor Shift'),
(5, 'Wednesday Full Shift', '2026-10-07', '10:00:00', '16:00:00', 'Mid-week Logistics Management'),
(6, 'Thursday Morning Assembly', '2026-10-08', '09:00:00', '13:00:00', 'Thursday Inventory Check'),
(7, 'Friday Closing Shift', '2026-10-09', '15:00:00', '21:00:00', 'Weekend Preparation & Closing');

-- Insert Initial Roster Assignments
INSERT INTO rosters (id, employee_id, shift_id, status, assigned_at) VALUES
(1, 1, 1, 'ASSIGNED', '2026-09-28 09:00:00'), -- Arun on Monday Morning (09:00 - 13:00)
(2, 2, 2, 'ASSIGNED', '2026-09-28 09:05:00'), -- Bala on Monday Afternoon (14:00 - 18:00)
(3, 3, 3, 'ASSIGNED', '2026-09-28 09:10:00'), -- Priya on Tuesday Morning
(4, 4, 4, 'ASSIGNED', '2026-09-28 09:15:00'), -- Divya on Tuesday Afternoon
(5, 1, 5, 'ASSIGNED', '2026-09-28 09:20:00'); -- Arun on Wednesday Full Shift

-- Insert Sample Swap Requests demonstrating different states
-- 1. Pending Colleague: Priya requests Divya's Tuesday Afternoon shift
INSERT INTO swap_requests (id, requester_id, target_employee_id, roster_id, reason, status, requested_at) VALUES
(1, 3, 4, 4, 'Need to swap for personal work on Tuesday afternoon', 'PENDING_COLLEAGUE', '2026-09-29 08:00:00');

-- 2. Colleague Accepted: Arun requested Bala's Monday Afternoon shift, Bala accepted
INSERT INTO swap_requests (id, requester_id, target_employee_id, roster_id, reason, status, requested_at, colleague_responded_at) VALUES
(2, 1, 2, 2, 'Arun doctor appointment in morning, wants Bala afternoon shift', 'COLLEAGUE_ACCEPTED', '2026-09-29 08:30:00', '2026-09-29 08:45:00');
