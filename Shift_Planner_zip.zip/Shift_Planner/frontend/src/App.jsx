import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

import Dashboard from './pages/Dashboard';
import Employees from './pages/Employees';
import AddEmployee from './pages/AddEmployee';
import Shifts from './pages/Shifts';
import AddShift from './pages/AddShift';
import WeeklyRoster from './pages/WeeklyRoster';
import AssignShift from './pages/AssignShift';
import RequestSwap from './pages/RequestSwap';
import MySwapRequests from './pages/MySwapRequests';
import ManagerApproval from './pages/ManagerApproval';

import { EmployeeAPI } from './services/api';

function App() {
  const [currentRole, setCurrentRole] = useState('EMPLOYEE'); // 'EMPLOYEE' or 'MANAGER'
  const [activeEmployeeId, setActiveEmployeeId] = useState(1); // Default to Arun (1)
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    try {
      const res = await EmployeeAPI.getAll();
      setEmployees(res.data || []);
    } catch (err) {
      console.error('Failed to load employees for App header', err);
    }
  };

  return (
    <Router>
      <div className="app-container">
        <Navbar
          currentRole={currentRole}
          setCurrentRole={setCurrentRole}
          activeEmployeeId={activeEmployeeId}
          setActiveEmployeeId={setActiveEmployeeId}
          employees={employees}
        />

        <main className="main-content">
          <Routes>
            <Route
              path="/"
              element={<Dashboard currentRole={currentRole} activeEmployeeId={activeEmployeeId} />}
            />
            <Route path="/employees" element={<Employees />} />
            <Route path="/add-employee" element={<AddEmployee onEmployeeCreated={loadEmployees} />} />
            <Route path="/shifts" element={<Shifts />} />
            <Route path="/add-shift" element={<AddShift />} />
            <Route path="/roster" element={<WeeklyRoster />} />
            <Route path="/assign-shift" element={<AssignShift />} />
            <Route
              path="/request-swap"
              element={<RequestSwap activeEmployeeId={activeEmployeeId} />}
            />
            <Route
              path="/swaps"
              element={
                <MySwapRequests
                  activeEmployeeId={activeEmployeeId}
                  currentRole={currentRole}
                />
              }
            />
            <Route path="/approval" element={<ManagerApproval />} />
          </Routes>
        </main>

        <Footer />
      </div>
    </Router>
  );
}

export default App;
