import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { EmployeeAPI, ShiftAPI, RosterAPI } from '../services/api';
import AlertModal from '../components/AlertModal';

const AssignShift = () => {
  const navigate = useNavigate();
  const [employees, setEmployees] = useState([]);
  const [shifts, setShifts] = useState([]);
  const [formData, setFormData] = useState({
    employeeId: '',
    shiftId: '',
  });

  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadDropdownData();
  }, []);

  const loadDropdownData = async () => {
    try {
      const [empRes, shiftRes] = await Promise.all([
        EmployeeAPI.getAll(),
        ShiftAPI.getAll(),
      ]);
      const activeEmps = (empRes.data || []).filter((e) => e.active);
      setEmployees(activeEmps);
      setShifts(shiftRes.data || []);

      if (activeEmps.length > 0) setFormData((prev) => ({ ...prev, employeeId: activeEmps[0].id }));
      if (shiftRes.data && shiftRes.data.length > 0) setFormData((prev) => ({ ...prev, shiftId: shiftRes.data[0].id }));
    } catch (err) {
      console.error('Failed to load dropdown data', err);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    try {
      await RosterAPI.assign({
        employeeId: Number(formData.employeeId),
        shiftId: Number(formData.shiftId),
      });

      setSuccess('Employee successfully assigned to shift!');
      setTimeout(() => {
        navigate('/roster');
      }, 1500);
    } catch (err) {
      // Backend returns ShiftOverlapException with status 409 and clear message
      const msg = err.response?.data?.message || 'Failed to assign shift';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Assign Shift to Employee</h1>
          <p className="page-subtitle">Schedule employee for a specific shift slot (Enforces overlap validation)</p>
        </div>
      </div>

      {error && <AlertModal message={error} type="error" onClose={() => setError(null)} />}
      {success && <AlertModal message={success} type="success" onClose={() => setSuccess(null)} />}

      <div className="card-container">
        <form onSubmit={handleSubmit}>
          <div className="form-grid" style={{ gridTemplateColumns: '1fr' }}>
            <div className="form-group">
              <label className="form-label">Select Active Employee *</label>
              <select
                name="employeeId"
                className="form-select"
                value={formData.employeeId}
                onChange={handleChange}
                required
              >
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.name} ({emp.employeeCode}) — {emp.role}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Select Shift Slot *</label>
              <select
                name="shiftId"
                className="form-select"
                value={formData.shiftId}
                onChange={handleChange}
                required
              >
                {shifts.map((shift) => (
                  <option key={shift.id} value={shift.id}>
                    {shift.shiftName} | {shift.shiftDate} ({shift.startTime} - {shift.endTime})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '1rem', marginTop: '1.5rem' }}>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Assigning...' : 'Assign Shift'}
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => navigate('/roster')}
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AssignShift;
