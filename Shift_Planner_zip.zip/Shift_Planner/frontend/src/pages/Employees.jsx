import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Users, UserCheck, UserX } from 'lucide-react';
import { EmployeeAPI } from '../services/api';

const Employees = () => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      setLoading(true);
      const res = await EmployeeAPI.getAll();
      setEmployees(res.data || []);
    } catch (err) {
      console.error('Failed to load employees', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDeactivate = async (id) => {
    if (window.confirm('Are you sure you want to deactivate this employee?')) {
      try {
        await EmployeeAPI.delete(id);
        fetchEmployees();
      } catch (err) {
        alert('Failed to deactivate employee');
      }
    }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Employee Directory</h1>
          <p className="page-subtitle">Manage staff profiles and organizational roles</p>
        </div>
        <Link to="/add-employee" className="btn btn-primary">
          <Plus size={16} /> Add Employee
        </Link>
      </div>

      <div className="card-container">
        {loading ? (
          <p style={{ color: 'var(--text-muted)' }}>Loading employees...</p>
        ) : (
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {employees.map((emp) => (
                  <tr key={emp.id}>
                    <td><code>{emp.employeeCode}</code></td>
                    <td><strong>{emp.name}</strong></td>
                    <td>{emp.email}</td>
                    <td>{emp.phone}</td>
                    <td>
                      <span style={{
                        padding: '0.2rem 0.5rem',
                        borderRadius: '0.25rem',
                        fontSize: '0.75rem',
                        fontWeight: 700,
                        background: emp.role === 'MANAGER' ? 'rgba(245, 158, 11, 0.2)' : 'rgba(59, 130, 246, 0.2)',
                        color: emp.role === 'MANAGER' ? '#fbbf24' : '#60a5fa'
                      }}>
                        {emp.role}
                      </span>
                    </td>
                    <td>
                      {emp.active ? (
                        <span style={{ color: '#34d399', display: 'flex', alignItems: 'center', gap: '0.25rem', fontWeight: 600 }}>
                          <UserCheck size={14} /> Active
                        </span>
                      ) : (
                        <span style={{ color: '#f87171', display: 'flex', alignItems: 'center', gap: '0.25rem', fontWeight: 600 }}>
                          <UserX size={14} /> Inactive
                        </span>
                      )}
                    </td>
                    <td>
                      {emp.active && (
                        <button
                          onClick={() => handleDeactivate(emp.id)}
                          className="btn btn-danger btn-sm"
                        >
                          Deactivate
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Employees;
