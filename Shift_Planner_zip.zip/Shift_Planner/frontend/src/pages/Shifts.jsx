import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Clock, Calendar } from 'lucide-react';
import { ShiftAPI } from '../services/api';

const Shifts = () => {
  const [shifts, setShifts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchShifts();
  }, []);

  const fetchShifts = async () => {
    try {
      setLoading(true);
      const res = await ShiftAPI.getAll();
      setShifts(res.data || []);
    } catch (err) {
      console.error('Failed to load shifts', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this shift?')) {
      try {
        await ShiftAPI.delete(id);
        fetchShifts();
      } catch (err) {
        alert('Failed to delete shift');
      }
    }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Shift Definitions</h1>
          <p className="page-subtitle">Configure working shift schedules and time slots</p>
        </div>
        <Link to="/add-shift" className="btn btn-primary">
          <Plus size={16} /> Add Shift
        </Link>
      </div>

      <div className="card-container">
        {loading ? (
          <p style={{ color: 'var(--text-muted)' }}>Loading shifts...</p>
        ) : (
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Shift Name</th>
                  <th>Date</th>
                  <th>Start Time</th>
                  <th>End Time</th>
                  <th>Description</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {shifts.map((s) => (
                  <tr key={s.id}>
                    <td>
                      <strong style={{ color: '#93c5fd' }}>{s.shiftName}</strong>
                    </td>
                    <td>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                        <Calendar size={14} color="var(--text-muted)" /> {s.shiftDate}
                      </span>
                    </td>
                    <td>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                        <Clock size={14} color="#34d399" /> {s.startTime}
                      </span>
                    </td>
                    <td>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                        <Clock size={14} color="#f87171" /> {s.endTime}
                      </span>
                    </td>
                    <td style={{ color: 'var(--text-muted)' }}>{s.description || '—'}</td>
                    <td>
                      <button
                        onClick={() => handleDelete(s.id)}
                        className="btn btn-danger btn-sm"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Shifts;
