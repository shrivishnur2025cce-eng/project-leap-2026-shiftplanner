import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Calendar } from 'lucide-react';
import { RosterAPI, EmployeeAPI } from '../services/api';
import StatusBadge from '../components/StatusBadge';

const WeeklyRoster = () => {
  const [rosters, setRosters] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRosterData();
  }, []);

  const fetchRosterData = async () => {
    try {
      setLoading(true);
      const [rosterRes, empRes] = await Promise.all([
        RosterAPI.getAll(),
        EmployeeAPI.getAll(),
      ]);
      setRosters(rosterRes.data || []);
      setEmployees((empRes.data || []).filter((e) => e.active));
    } catch (err) {
      console.error('Failed to load roster data', err);
    } finally {
      setLoading(false);
    }
  };

  // Helper to determine day of week from shiftDate (e.g. 2026-10-05 -> Monday)
  const getDayOfWeek = (dateStr) => {
    const date = new Date(dateStr);
    const day = date.getDay(); // 0 is Sunday, 1 is Monday...
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[day];
  };

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  // Map employee and day to matching roster shifts
  const getRostersForEmployeeAndDay = (employeeId, dayName) => {
    return rosters.filter((r) => {
      if (r.employee.id !== employeeId) return false;
      const day = getDayOfWeek(r.shift.shiftDate);
      return day === dayName;
    });
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Weekly Roster View</h1>
          <p className="page-subtitle">Interactive weekly shift grid across all team members</p>
        </div>
        <Link to="/assign-shift" className="btn btn-primary">
          <Plus size={16} /> Assign Shift
        </Link>
      </div>

      <div className="card-container">
        {loading ? (
          <p style={{ color: 'var(--text-muted)' }}>Loading weekly roster grid...</p>
        ) : (
          <div className="table-responsive">
            <table className="custom-table roster-grid-table">
              <thead>
                <tr>
                  <th style={{ textAlign: 'left', minWidth: '180px' }}>Employee</th>
                  {daysOfWeek.map((day) => (
                    <th key={day}>{day}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {employees.map((emp) => (
                  <tr key={emp.id}>
                    <td style={{ textAlign: 'left' }}>
                      <strong>{emp.name}</strong>
                      <br />
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        {emp.employeeCode} ({emp.role})
                      </span>
                    </td>
                    {daysOfWeek.map((day) => {
                      const dayRosters = getRostersForEmployeeAndDay(emp.id, day);
                      return (
                        <td key={day}>
                          {dayRosters.length === 0 ? (
                            <span style={{ color: '#475569', fontSize: '0.8rem' }}>Off</span>
                          ) : (
                            dayRosters.map((r) => (
                              <div key={r.id} className="shift-cell">
                                <span className="shift-title">{r.shift.shiftName}</span>
                                <span className="shift-time">
                                  {r.shift.startTime} - {r.shift.endTime}
                                </span>
                                <div style={{ marginTop: '0.2rem' }}>
                                  <StatusBadge status={r.status} />
                                </div>
                              </div>
                            ))
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default WeeklyRoster;
