import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { EmployeeAPI, RosterAPI, SwapAPI } from '../services/api';
import AlertModal from '../components/AlertModal';

const RequestSwap = ({ activeEmployeeId }) => {
  const navigate = useNavigate();
  const [employees, setEmployees] = useState([]);
  const [rosters, setRosters] = useState([]);
  
  const [formData, setFormData] = useState({
    requesterId: activeEmployeeId || '',
    targetEmployeeId: '',
    rosterId: '',
    reason: '',
  });

  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadSwapOptions();
  }, [activeEmployeeId]);

  const loadSwapOptions = async () => {
    try {
      const [empRes, rosterRes] = await Promise.all([
        EmployeeAPI.getAll(),
        RosterAPI.getAll(),
      ]);

      const activeEmps = (empRes.data || []).filter((e) => e.active);
      setEmployees(activeEmps);

      const allRosters = rosterRes.data || [];
      setRosters(allRosters);

      const requesterId = activeEmployeeId || (activeEmps.length > 0 ? activeEmps[0].id : '');
      const potentialTargets = activeEmps.filter((e) => e.id !== requesterId);
      const targetId = potentialTargets.length > 0 ? potentialTargets[0].id : '';

      // Find rosters belonging to targetId
      const targetRosters = allRosters.filter((r) => r.employee.id === targetId);
      const rosterId = targetRosters.length > 0 ? targetRosters[0].id : (allRosters.length > 0 ? allRosters[0].id : '');

      setFormData({
        requesterId,
        targetEmployeeId: targetId,
        rosterId,
        reason: 'Personal work commitment',
      });
    } catch (err) {
      console.error('Failed to load swap request options', err);
    }
  };

  const handleTargetChange = (e) => {
    const targetId = Number(e.target.value);
    const targetRosters = rosters.filter((r) => r.employee.id === targetId);
    const rosterId = targetRosters.length > 0 ? targetRosters[0].id : '';

    setFormData((prev) => ({
      ...prev,
      targetEmployeeId: targetId,
      rosterId,
    }));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    try {
      await SwapAPI.create({
        requesterId: Number(formData.requesterId),
        targetEmployeeId: Number(formData.targetEmployeeId),
        rosterId: Number(formData.rosterId),
        reason: formData.reason,
      });

      setSuccess('Swap request created successfully! Initial status: PENDING_COLLEAGUE');
      setTimeout(() => {
        navigate('/swaps');
      }, 1500);
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to submit swap request';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  // Filter rosters that belong to the selected target employee
  const availableTargetRosters = rosters.filter(
    (r) => r.employee.id === Number(formData.targetEmployeeId)
  );

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Request Shift Swap</h1>
          <p className="page-subtitle">Submit a shift exchange request to a colleague</p>
        </div>
      </div>

      {error && <AlertModal message={error} type="error" onClose={() => setError(null)} />}
      {success && <AlertModal message={success} type="success" onClose={() => setSuccess(null)} />}

      <div className="card-container">
        <form onSubmit={handleSubmit}>
          <div className="form-grid" style={{ gridTemplateColumns: '1fr' }}>
            <div className="form-group">
              <label className="form-label">Requester Employee *</label>
              <select
                name="requesterId"
                className="form-select"
                value={formData.requesterId}
                onChange={handleChange}
                required
              >
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.name} ({emp.employeeCode})
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Select Target Colleague to Swap With *</label>
              <select
                name="targetEmployeeId"
                className="form-select"
                value={formData.targetEmployeeId}
                onChange={handleTargetChange}
                required
              >
                {employees
                  .filter((emp) => emp.id !== Number(formData.requesterId))
                  .map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.employeeCode})
                    </option>
                  ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Select Target Colleague's Shift Roster *</label>
              <select
                name="rosterId"
                className="form-select"
                value={formData.rosterId}
                onChange={handleChange}
                required
              >
                {availableTargetRosters.length === 0 ? (
                  <option value="">No shifts assigned to this colleague</option>
                ) : (
                  availableTargetRosters.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.shift.shiftName} | {r.shift.shiftDate} ({r.shift.startTime} - {r.shift.endTime})
                    </option>
                  ))
                )}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Reason for Swap *</label>
              <textarea
                name="reason"
                className="form-textarea"
                rows="3"
                placeholder="Explain why you are requesting this swap..."
                value={formData.reason}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div style={{ display: 'flex', gap: '1rem', marginTop: '1.5rem' }}>
            <button
              type="submit"
              className="btn btn-primary"
              disabled={loading || availableTargetRosters.length === 0}
            >
              {loading ? 'Submitting...' : 'Submit Swap Request'}
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => navigate('/swaps')}
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RequestSwap;
