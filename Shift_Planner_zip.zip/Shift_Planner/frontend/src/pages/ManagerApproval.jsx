import React, { useEffect, useState } from 'react';
import { CheckCircle, XCircle, ShieldCheck } from 'lucide-react';
import { SwapAPI } from '../services/api';
import StatusBadge from '../components/StatusBadge';
import AlertModal from '../components/AlertModal';

const ManagerApproval = () => {
  const [acceptedSwaps, setAcceptedSwaps] = useState([]);
  const [allSwaps, setAllSwaps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  useEffect(() => {
    fetchManagerSwaps();
  }, []);

  const fetchManagerSwaps = async () => {
    try {
      setLoading(true);
      const res = await SwapAPI.getAll();
      const data = res.data || [];
      setAllSwaps(data);
      const pendingApproval = data.filter((s) => s.status === 'COLLEAGUE_ACCEPTED');
      setAcceptedSwaps(pendingApproval);
    } catch (err) {
      console.error('Failed to load manager swap queue', err);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (id) => {
    setError(null);
    setSuccess(null);
    try {
      await SwapAPI.approve(id, 5); // 5 is Manager Kumar ID in sample database
      setSuccess('Swap request APPROVED! Roster updated and employee assignment swapped.');
      fetchManagerSwaps();
    } catch (err) {
      const msg = err.response?.data?.message || 'Manager approval failed';
      setError(msg);
    }
  };

  const handleReject = async (id) => {
    setError(null);
    setSuccess(null);
    try {
      await SwapAPI.reject(id, 5);
      setSuccess('Swap request REJECTED by manager.');
      fetchManagerSwaps();
    } catch (err) {
      const msg = err.response?.data?.message || 'Manager rejection failed';
      setError(msg);
    }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Manager Swap Approval Panel</h1>
          <p className="page-subtitle">Review colleague-accepted shift swaps before final roster updating</p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(16, 185, 129, 0.15)', padding: '0.5rem 1rem', borderRadius: '0.5rem', color: '#34d399', fontWeight: 600 }}>
          <ShieldCheck size={18} /> Manager Authorization Mode
        </div>
      </div>

      {error && <AlertModal message={error} type="error" onClose={() => setError(null)} />}
      {success && <AlertModal message={success} type="success" onClose={() => setSuccess(null)} />}

      {/* Pending Approval Section */}
      <div className="card-container" style={{ marginBottom: '2rem' }}>
        <div className="card-title">
          <span>Awaiting Final Manager Approval ({acceptedSwaps.length})</span>
        </div>
        {loading ? (
          <p style={{ color: 'var(--text-muted)' }}>Loading approval queue...</p>
        ) : (
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Request ID</th>
                  <th>Requester</th>
                  <th>Colleague (Target)</th>
                  <th>Shift Details</th>
                  <th>Reason</th>
                  <th>Current Status</th>
                  <th>Manager Action</th>
                </tr>
              </thead>
              <tbody>
                {acceptedSwaps.length === 0 ? (
                  <tr>
                    <td colSpan="7" style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '2rem' }}>
                      🎉 No pending swap requests requiring manager approval right now.
                    </td>
                  </tr>
                ) : (
                  acceptedSwaps.map((s) => (
                    <tr key={s.id}>
                      <td><code>#SWAP-{s.id}</code></td>
                      <td>
                        <strong>{s.requester?.name}</strong>
                      </td>
                      <td>
                        <strong>{s.targetEmployee?.name}</strong>
                      </td>
                      <td>
                        <span style={{ color: '#93c5fd', fontWeight: 600 }}>{s.roster?.shift?.shiftName}</span>
                        <br />
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          {s.roster?.shift?.shiftDate} ({s.roster?.shift?.startTime} - {s.roster?.shift?.endTime})
                        </span>
                      </td>
                      <td>{s.reason || '—'}</td>
                      <td>
                        <StatusBadge status={s.status} />
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                          <button
                            onClick={() => handleApprove(s.id)}
                            className="btn btn-success btn-sm"
                          >
                            <CheckCircle size={14} /> Approve Swap
                          </button>
                          <button
                            onClick={() => handleReject(s.id)}
                            className="btn btn-danger btn-sm"
                          >
                            <XCircle size={14} /> Reject
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Historical Audit Log */}
      <div className="card-container">
        <div className="card-title">
          <span>All Swap Requests Audit History</span>
        </div>
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Requester</th>
                <th>Target</th>
                <th>Shift Date</th>
                <th>Status</th>
                <th>Requested At</th>
                <th>Colleague Responded</th>
                <th>Manager Approved</th>
              </tr>
            </thead>
            <tbody>
              {allSwaps.map((s) => (
                <tr key={s.id}>
                  <td><code>#{s.id}</code></td>
                  <td>{s.requester?.name}</td>
                  <td>{s.targetEmployee?.name}</td>
                  <td>{s.roster?.shift?.shiftDate}</td>
                  <td><StatusBadge status={s.status} /></td>
                  <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{s.requestedAt ? new Date(s.requestedAt).toLocaleString() : '—'}</td>
                  <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{s.colleagueRespondedAt ? new Date(s.colleagueRespondedAt).toLocaleString() : '—'}</td>
                  <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{s.managerApprovedAt ? new Date(s.managerApprovedAt).toLocaleString() : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ManagerApproval;
