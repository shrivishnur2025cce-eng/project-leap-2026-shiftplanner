import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Users, Clock, Calendar, RefreshCw, CheckCircle, Plus, ArrowRight } from 'lucide-react';
import { EmployeeAPI, ShiftAPI, RosterAPI, SwapAPI } from '../services/api';
import StatusBadge from '../components/StatusBadge';

const Dashboard = ({ currentRole, activeEmployeeId }) => {
  const [stats, setStats] = useState({
    totalEmployees: 0,
    totalShifts: 0,
    todaysAssignments: 0,
    pendingSwaps: 0,
    approvedSwaps: 0,
  });
  const [recentRosters, setRecentRosters] = useState([]);
  const [recentSwaps, setRecentSwaps] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [empRes, shiftRes, rosterRes, swapRes] = await Promise.all([
        EmployeeAPI.getAll(),
        ShiftAPI.getAll(),
        RosterAPI.getAll(),
        SwapAPI.getAll(),
      ]);

      const employees = empRes.data || [];
      const shifts = shiftRes.data || [];
      const rosters = rosterRes.data || [];
      const swaps = swapRes.data || [];

      const pending = swaps.filter((s) => s.status === 'PENDING_COLLEAGUE' || s.status === 'COLLEAGUE_ACCEPTED').length;
      const approved = swaps.filter((s) => s.status === 'MANAGER_APPROVED' || s.status === 'COMPLETED').length;

      setStats({
        totalEmployees: employees.length,
        totalShifts: shifts.length,
        todaysAssignments: rosters.length,
        pendingSwaps: pending,
        approvedSwaps: approved,
      });

      setRecentRosters(rosters.slice(0, 5));
      setRecentSwaps(swaps.slice(0, 5));
    } catch (err) {
      console.error('Failed to load dashboard statistics', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
        Loading Dashboard Data...
      </div>
    );
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Operational Dashboard</h1>
          <p className="page-subtitle">Shift Roster Summary & Active Swap Workflow Overview</p>
        </div>
        {currentRole === 'MANAGER' ? (
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            <Link to="/add-shift" className="btn btn-primary">
              <Plus size={16} /> Add Shift
            </Link>
            <Link to="/assign-shift" className="btn btn-success">
              <Plus size={16} /> Assign Employee
            </Link>
          </div>
        ) : (
          <Link to="/request-swap" className="btn btn-primary">
            <RefreshCw size={16} /> Request Shift Swap
          </Link>
        )}
      </div>

      {/* Stats Cards Grid */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(59, 130, 246, 0.2)', color: '#60a5fa' }}>
            <Users size={24} />
          </div>
          <div className="stat-info">
            <h3>{stats.totalEmployees}</h3>
            <p>Total Employees</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(139, 92, 246, 0.2)', color: '#c084fc' }}>
            <Clock size={24} />
          </div>
          <div className="stat-info">
            <h3>{stats.totalShifts}</h3>
            <p>Configured Shifts</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(6, 182, 212, 0.2)', color: '#22d3ee' }}>
            <Calendar size={24} />
          </div>
          <div className="stat-info">
            <h3>{stats.todaysAssignments}</h3>
            <p>Active Roster Assignments</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(245, 158, 11, 0.2)', color: '#fbbf24' }}>
            <RefreshCw size={24} />
          </div>
          <div className="stat-info">
            <h3>{stats.pendingSwaps}</h3>
            <p>Pending Swap Requests</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(16, 185, 129, 0.2)', color: '#34d399' }}>
            <CheckCircle size={24} />
          </div>
          <div className="stat-info">
            <h3>{stats.approvedSwaps}</h3>
            <p>Completed Swaps</p>
          </div>
        </div>
      </div>

      {/* Grid of Tables */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(450px, 1fr))', gap: '1.5rem' }}>
        {/* Recent Roster Assignments */}
        <div className="card-container">
          <div className="card-title">
            <span>Recent Roster Assignments</span>
            <Link to="/roster" style={{ color: 'var(--primary)', textDecoration: 'none', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
              View All <ArrowRight size={14} />
            </Link>
          </div>
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Employee</th>
                  <th>Shift Name</th>
                  <th>Date & Time</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {recentRosters.length === 0 ? (
                  <tr>
                    <td colSpan="4" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
                      No roster assignments found
                    </td>
                  </tr>
                ) : (
                  recentRosters.map((r) => (
                    <tr key={r.id}>
                      <td>
                        <strong>{r.employee.name}</strong> ({r.employee.employeeCode})
                      </td>
                      <td>{r.shift.shiftName}</td>
                      <td>
                        {r.shift.shiftDate} <br />
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          {r.shift.startTime} - {r.shift.endTime}
                        </span>
                      </td>
                      <td>
                        <StatusBadge status={r.status} />
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Swap Requests */}
        <div className="card-container">
          <div className="card-title">
            <span>Active Shift Swap Requests</span>
            <Link to="/swaps" style={{ color: 'var(--primary)', textDecoration: 'none', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
              View All <ArrowRight size={14} />
            </Link>
          </div>
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Requester</th>
                  <th>Target Employee</th>
                  <th>Shift Date</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {recentSwaps.length === 0 ? (
                  <tr>
                    <td colSpan="4" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
                      No swap requests submitted
                    </td>
                  </tr>
                ) : (
                  recentSwaps.map((s) => (
                    <tr key={s.id}>
                      <td>
                        <strong>{s.requester.name}</strong>
                      </td>
                      <td>{s.targetEmployee.name}</td>
                      <td>{s.roster?.shift?.shiftDate}</td>
                      <td>
                        <StatusBadge status={s.status} />
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
