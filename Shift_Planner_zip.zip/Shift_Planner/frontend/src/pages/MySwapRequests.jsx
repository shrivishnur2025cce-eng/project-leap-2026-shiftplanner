import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Check, X, RefreshCw } from 'lucide-react';
import { SwapAPI } from '../services/api';
import StatusBadge from '../components/StatusBadge';
import AlertModal from '../components/AlertModal';

const MySwapRequests = ({ activeEmployeeId, currentRole }) => {
  const [swaps, setSwaps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  useEffect(() => {
    fetchSwaps();
  }, [activeEmployeeId, currentRole]);

  const fetchSwaps = async () => {
    try {
      setLoading(true);
      const res = await SwapAPI.getAll();
      setSwaps(res.data || []);
    } catch (err) {
      console.error('Failed to load swap requests', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async (id) => {
    setError(null);
    setSuccess(null);
    try {
      await SwapAPI.accept(id, activeEmployeeId);
      setSuccess('Swap request accepted! Status updated to COLLEAGUE_ACCEPTED. Awaiting manager final approval.');
      fetchSwaps();
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to accept swap request';
      setError(msg);
    }
  };

  const handleDecline = async (id) => {
    setError(null);
    setSuccess(null);
    try {
      await SwapAPI.decline(id, activeEmployeeId);
      setSuccess('Swap request declined. Status updated to COLLEAGUE_DECLINED.');
      fetchSwaps();
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to decline swap request';
      setError(msg);
    }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Shift Swap Requests</h1>
          <p className="page-subtitle">Track requested, pending, accepted, and approved shift swaps</p>
        </div>
        <Link to="/request-swap" className="btn btn-primary">
          <Plus size={16} /> New Swap Request
        </Link>
      </div>

      {error && <AlertModal message={error} type="error" onClose={() => setError(null)} />}
      {success && <AlertModal message={success} type="success" onClose={() => setSuccess(null)} />}

      <div className="card-container">
        {loading ? (
          <p style={{ color: 'var(--text-muted)' }}>Loading swap requests...</p>
        ) : (
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Request ID</th>
                  <th>Requester</th>
                  <th>Target Colleague</th>
                  <th>Shift Details</th>
                  <th>Reason</th>
                  <th>Status</th>
                  <th>Colleague Action</th>
                </tr>
              </thead>
              <tbody>
                {swaps.length === 0 ? (
                  <tr>
                    <td colSpan="7" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
                      No swap requests recorded in system.
                    </td>
                  </tr>
                ) : (
                  swaps.map((s) => {
                    const isTargetColleague = s.targetEmployee?.id === activeEmployeeId;
                    const canRespond = isTargetColleague && s.status === 'PENDING_COLLEAGUE';

                    return (
                      <tr key={s.id}>
                        <td><code>#SWAP-{s.id}</code></td>
                        <td>
                          <strong>{s.requester?.name}</strong>
                          <br />
                          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                            {s.requester?.employeeCode}
                          </span>
                        </td>
                        <td>
                          <strong>{s.targetEmployee?.name}</strong>
                          <br />
                          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                            {s.targetEmployee?.employeeCode}
                          </span>
                        </td>
                        <td>
                          <span style={{ color: '#93c5fd', fontWeight: 600 }}>{s.roster?.shift?.shiftName}</span>
                          <br />
                          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                            {s.roster?.shift?.shiftDate} ({s.roster?.shift?.startTime} - {s.roster?.shift?.endTime})
                          </span>
                        </td>
                        <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>{s.reason || '—'}</td>
                        <td>
                          <StatusBadge status={s.status} />
                        </td>
                        <td>
                          {canRespond ? (
                            <div style={{ display: 'flex', gap: '0.5rem' }}>
                              <button
                                onClick={() => handleAccept(s.id)}
                                className="btn btn-success btn-sm"
                              >
                                <Check size={14} /> Accept
                              </button>
                              <button
                                onClick={() => handleDecline(s.id)}
                                className="btn btn-danger btn-sm"
                              >
                                <X size={14} /> Decline
                              </button>
                            </div>
                          ) : s.status === 'PENDING_COLLEAGUE' ? (
                            <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                              Awaiting {s.targetEmployee?.name}
                            </span>
                          ) : (
                            <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                              Completed Action
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default MySwapRequests;
