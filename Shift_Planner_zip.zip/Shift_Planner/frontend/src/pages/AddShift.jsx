import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShiftAPI } from '../services/api';
import AlertModal from '../components/AlertModal';

const AddShift = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    shiftName: '',
    shiftDate: '2026-10-05',
    startTime: '09:00',
    endTime: '13:00',
    description: '',
  });

  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      // Ensure times have HH:mm:ss format for Java LocalTime parsing
      const startTimeFormatted = formData.startTime.length === 5 ? `${formData.startTime}:00` : formData.startTime;
      const endTimeFormatted = formData.endTime.length === 5 ? `${formData.endTime}:00` : formData.endTime;

      await ShiftAPI.create({
        ...formData,
        startTime: startTimeFormatted,
        endTime: endTimeFormatted,
      });

      navigate('/shifts');
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to create shift';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Create New Shift</h1>
          <p className="page-subtitle">Define shift date and working time window</p>
        </div>
      </div>

      {error && <AlertModal message={error} type="error" onClose={() => setError(null)} />}

      <div className="card-container">
        <form onSubmit={handleSubmit}>
          <div className="form-grid" style={{ gridTemplateColumns: '1fr' }}>
            <div className="form-group">
              <label className="form-label">Shift Name *</label>
              <input
                type="text"
                name="shiftName"
                className="form-input"
                placeholder="e.g. Monday Morning Assembly"
                value={formData.shiftName}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Shift Date *</label>
              <input
                type="date"
                name="shiftDate"
                className="form-input"
                value={formData.shiftDate}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
              <div className="form-group">
                <label className="form-label">Start Time *</label>
                <input
                  type="time"
                  name="startTime"
                  className="form-input"
                  value={formData.startTime}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">End Time *</label>
                <input
                  type="time"
                  name="endTime"
                  className="form-input"
                  value={formData.endTime}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea
                name="description"
                className="form-textarea"
                rows="3"
                placeholder="Optional notes or details about the shift..."
                value={formData.description}
                onChange={handleChange}
              />
            </div>
          </div>

          <div style={{ display: 'flex', gap: '1rem', marginTop: '1.5rem' }}>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Creating...' : 'Save Shift'}
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => navigate('/shifts')}
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddShift;
