import React from 'react';
import { AlertTriangle, CheckCircle, X } from 'lucide-react';

const AlertModal = ({ message, type = 'error', onClose }) => {
  if (!message) return null;

  return (
    <div className={`alert-banner ${type === 'error' ? 'alert-error' : 'alert-success'}`}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flex: 1 }}>
        {type === 'error' ? <AlertTriangle size={20} /> : <CheckCircle size={20} />}
        <div>
          <strong style={{ display: 'block', fontSize: '0.95rem' }}>
            {type === 'error' ? 'Action Rejected / Conflict Error' : 'Success'}
          </strong>
          <span>{message}</span>
        </div>
      </div>
      {onClose && (
        <button
          onClick={onClose}
          style={{ background: 'transparent', border: 'none', color: 'inherit', cursor: 'pointer' }}
        >
          <X size={18} />
        </button>
      )}
    </div>
  );
};

export default AlertModal;
