import React from 'react';

const StatusBadge = ({ status }) => {
  if (!status) return null;

  let badgeClass = 'badge-assigned';
  let label = status;

  switch (status) {
    case 'ASSIGNED':
      badgeClass = 'badge-assigned';
      label = 'Assigned';
      break;
    case 'PENDING_COLLEAGUE':
      badgeClass = 'badge-pending';
      label = 'Pending Colleague';
      break;
    case 'COLLEAGUE_ACCEPTED':
      badgeClass = 'badge-accepted';
      label = 'Colleague Accepted';
      break;
    case 'COLLEAGUE_DECLINED':
      badgeClass = 'badge-declined';
      label = 'Colleague Declined';
      break;
    case 'MANAGER_APPROVED':
    case 'COMPLETED':
    case 'SWAPPED':
      badgeClass = 'badge-approved';
      label = status === 'COMPLETED' ? 'Completed' : (status === 'SWAPPED' ? 'Swapped' : 'Manager Approved');
      break;
    case 'MANAGER_REJECTED':
      badgeClass = 'badge-rejected';
      label = 'Manager Rejected';
      break;
    default:
      badgeClass = 'badge-assigned';
      label = status;
  }

  return <span className={`badge ${badgeClass}`}>{label}</span>;
};

export default StatusBadge;
