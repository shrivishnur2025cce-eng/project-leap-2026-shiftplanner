import React from 'react';

const Footer = () => {
  return (
    <footer className="footer">
      <p>© 2026 ShiftPlanner — Employee Shift Roster & Swap Request System | College Major Project</p>
    </footer>
  );
};

export default Footer;
