import React from 'react';
import { NavLink } from 'react-router-dom';
import { Calendar, Users, Clock, RefreshCw, CheckSquare, PlusCircle, ShieldCheck, User } from 'lucide-react';

const Navbar = ({ currentRole, setCurrentRole, activeEmployeeId, setActiveEmployeeId, employees }) => {
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <NavLink to="/" className="brand">
          <Calendar size={28} style={{ color: '#3b82f6' }} />
          <span>ShiftPlanner</span>
        </NavLink>

        <ul className="nav-links">
          <li>
            <NavLink to="/" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              Dashboard
            </NavLink>
          </li>
          <li>
            <NavLink to="/roster" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              <Calendar size={16} /> Roster
            </NavLink>
          </li>
          <li>
            <NavLink to="/swaps" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              <RefreshCw size={16} /> My Swaps
            </NavLink>
          </li>

          {currentRole === 'MANAGER' ? (
            <>
              <li>
                <NavLink to="/approval" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                  <CheckSquare size={16} /> Approvals
                </NavLink>
              </li>
              <li>
                <NavLink to="/employees" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                  <Users size={16} /> Employees
                </NavLink>
              </li>
              <li>
                <NavLink to="/shifts" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                  <Clock size={16} /> Shifts
                </NavLink>
              </li>
              <li>
                <NavLink to="/assign-shift" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                  <PlusCircle size={16} /> Assign Shift
                </NavLink>
              </li>
            </>
          ) : (
            <li>
              <NavLink to="/request-swap" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                <PlusCircle size={16} /> Request Swap
              </NavLink>
            </li>
          )}
        </ul>

        {/* Role & User Selector Bar */}
        <div className="role-selector-box">
          {currentRole === 'MANAGER' ? <ShieldCheck size={18} color="#10b981" /> : <User size={18} color="#3b82f6" />}
          
          <select
            className="role-select"
            value={currentRole === 'MANAGER' ? 'MANAGER' : activeEmployeeId}
            onChange={(e) => {
              const val = e.target.value;
              if (val === 'MANAGER') {
                setCurrentRole('MANAGER');
              } else {
                setCurrentRole('EMPLOYEE');
                setActiveEmployeeId(Number(val));
              }
            }}
          >
            <optgroup label="Manager Role">
              <option value="MANAGER">👑 Manager (Kumar)</option>
            </optgroup>
            <optgroup label="Employee Login Simulation">
              {employees && employees.filter(e => e.role === 'EMPLOYEE').map(emp => (
                <option key={emp.id} value={emp.id}>
                  👤 {emp.name} ({emp.employeeCode})
                </option>
              ))}
            </optgroup>
          </select>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
