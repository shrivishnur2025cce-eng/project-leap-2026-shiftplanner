import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const EmployeeAPI = {
  getAll: () => api.get('/employees'),
  getById: (id) => api.get(`/employees/${id}`),
  create: (data) => api.post('/employees', data),
  update: (id, data) => api.put(`/employees/${id}`, data),
  delete: (id) => api.delete(`/employees/${id}`),
};

export const ShiftAPI = {
  getAll: (date) => api.get('/shifts', { params: { date } }),
  getById: (id) => api.get(`/shifts/${id}`),
  create: (data) => api.post('/shifts', data),
  update: (id, data) => api.put(`/shifts/${id}`, data),
  delete: (id) => api.delete(`/shifts/${id}`),
};

export const RosterAPI = {
  getAll: (employeeId) => api.get('/roster', { params: { employeeId } }),
  getByDate: (date) => api.get(`/roster/date/${date}`),
  assign: (data) => api.post('/roster/assign', data),
  delete: (id) => api.delete(`/roster/${id}`),
};

export const SwapAPI = {
  getAll: (employeeId) => api.get('/swaps', { params: { employeeId } }),
  getById: (id) => api.get(`/swaps/${id}`),
  create: (data) => api.post('/swaps', data),
  accept: (id, colleagueId) => api.put(`/swaps/${id}/accept`, null, { params: { colleagueId } }),
  decline: (id, colleagueId) => api.put(`/swaps/${id}/decline`, null, { params: { colleagueId } }),
  approve: (id, managerId) => api.put(`/swaps/${id}/approve`, null, { params: { managerId } }),
  reject: (id, managerId) => api.put(`/swaps/${id}/reject`, null, { params: { managerId } }),
};

export default api;
