package com.shiftplanner.exception;

public class ShiftOverlapException extends RuntimeException {
    public ShiftOverlapException(String message) {
        super(message);
    }
}
