package com.shiftplanner.controller;

import com.shiftplanner.dto.CreateSwapRequest;
import com.shiftplanner.dto.SwapResponse;
import com.shiftplanner.service.SwapRequestService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/swaps")
@RequiredArgsConstructor
@Tag(name = "Swap Request Controller", description = "Endpoints for managing shift swap requests and multi-step approvals")
public class SwapRequestController {

    private final SwapRequestService swapRequestService;

    @GetMapping
    @Operation(summary = "Get all shift swap requests or filter by employee")
    public ResponseEntity<List<SwapResponse>> getAllSwapRequests(
            @RequestParam(required = false) Long employeeId) {
        if (employeeId != null) {
            return ResponseEntity.ok(swapRequestService.getSwapRequestsByEmployee(employeeId));
        }
        return ResponseEntity.ok(swapRequestService.getAllSwapRequests());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get swap request details by ID")
    public ResponseEntity<SwapResponse> getSwapRequestById(@PathVariable Long id) {
        return ResponseEntity.ok(swapRequestService.getSwapRequestById(id));
    }

    @PostMapping
    @Operation(summary = "Create a new shift swap request")
    public ResponseEntity<SwapResponse> createSwapRequest(@Valid @RequestBody CreateSwapRequest request) {
        SwapResponse created = swapRequestService.createSwapRequest(request);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @PutMapping("/{id}/accept")
    @Operation(summary = "Target colleague accepts the swap request")
    public ResponseEntity<SwapResponse> acceptByColleague(
            @PathVariable Long id,
            @RequestParam(required = false) Long colleagueId) {
        return ResponseEntity.ok(swapRequestService.acceptByColleague(id, colleagueId));
    }

    @PutMapping("/{id}/decline")
    @Operation(summary = "Target colleague declines the swap request")
    public ResponseEntity<SwapResponse> declineByColleague(
            @PathVariable Long id,
            @RequestParam(required = false) Long colleagueId) {
        return ResponseEntity.ok(swapRequestService.declineByColleague(id, colleagueId));
    }

    @PutMapping("/{id}/approve")
    @Operation(summary = "Manager approves swap request and applies roster changes")
    public ResponseEntity<SwapResponse> approveByManager(
            @PathVariable Long id,
            @RequestParam(required = false) Long managerId) {
        return ResponseEntity.ok(swapRequestService.approveByManager(id, managerId));
    }

    @PutMapping("/{id}/reject")
    @Operation(summary = "Manager rejects the swap request")
    public ResponseEntity<SwapResponse> rejectByManager(
            @PathVariable Long id,
            @RequestParam(required = false) Long managerId) {
        return ResponseEntity.ok(swapRequestService.rejectByManager(id, managerId));
    }
}
