package com.shiftplanner.dto;

import com.shiftplanner.entity.SwapStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SwapResponse {
    private Long id;
    private EmployeeResponse requester;
    private EmployeeResponse targetEmployee;
    private RosterResponse roster;
    private String reason;
    private SwapStatus status;
    private LocalDateTime requestedAt;
    private LocalDateTime colleagueRespondedAt;
    private LocalDateTime managerApprovedAt;
}
