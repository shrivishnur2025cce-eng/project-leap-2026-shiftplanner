package com.shiftplanner.repository;

import com.shiftplanner.entity.SwapRequest;
import com.shiftplanner.entity.SwapStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SwapRequestRepository extends JpaRepository<SwapRequest, Long> {

    List<SwapRequest> findByRequesterId(Long requesterId);

    List<SwapRequest> findByTargetEmployeeId(Long targetEmployeeId);

    List<SwapRequest> findByStatus(SwapStatus status);

    @Query("SELECT s FROM SwapRequest s WHERE s.requester.id = :employeeId OR s.targetEmployee.id = :employeeId")
    List<SwapRequest> findByEmployeeId(@Param("employeeId") Long employeeId);

    List<SwapRequest> findByRosterIdAndStatusIn(Long rosterId, List<SwapStatus> statuses);
}
