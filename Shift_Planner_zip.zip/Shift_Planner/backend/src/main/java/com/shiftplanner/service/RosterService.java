package com.shiftplanner.service;

import com.shiftplanner.dto.AssignRosterRequest;
import com.shiftplanner.dto.RosterResponse;
import com.shiftplanner.entity.Employee;
import com.shiftplanner.entity.Roster;
import com.shiftplanner.entity.RosterStatus;
import com.shiftplanner.entity.Shift;
import com.shiftplanner.exception.InvalidSwapException;
import com.shiftplanner.exception.ResourceNotFoundException;
import com.shiftplanner.exception.ShiftOverlapException;
import com.shiftplanner.repository.EmployeeRepository;
import com.shiftplanner.repository.RosterRepository;
import com.shiftplanner.repository.ShiftRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RosterService {

    private final RosterRepository rosterRepository;
    private final EmployeeRepository employeeRepository;
    private final ShiftRepository shiftRepository;
    private final EmployeeService employeeService;
    private final ShiftService shiftService;

    @Transactional(readOnly = true)
    public List<RosterResponse> getAllRosters() {
        return rosterRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<RosterResponse> getRostersByDate(LocalDate date) {
        return rosterRepository.findByShiftShiftDate(date).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<RosterResponse> getRostersByEmployeeId(Long employeeId) {
        return rosterRepository.findByEmployeeId(employeeId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public RosterResponse assignRoster(AssignRosterRequest request) {
        // 1. Check employee exists
        Employee employee = employeeRepository.findById(request.getEmployeeId())
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + request.getEmployeeId()));

        // 2. Check employee is active
        if (!employee.isActive()) {
            throw new InvalidSwapException("Cannot assign shift to inactive employee: " + employee.getName());
        }

        // 3. Check shift exists
        Shift shift = shiftRepository.findById(request.getShiftId())
                .orElseThrow(() -> new ResourceNotFoundException("Shift not found with id: " + request.getShiftId()));

        // 4. Check whether employee already has an overlapping shift on that date
        List<Roster> overlapping = rosterRepository.findOverlappingRosters(
                employee.getId(),
                shift.getShiftDate(),
                shift.getStartTime(),
                shift.getEndTime()
        );

        if (!overlapping.isEmpty()) {
            Roster existingRoster = overlapping.get(0);
            Shift existingShift = existingRoster.getShift();
            throw new ShiftOverlapException(String.format(
                    "Employee %s already has an overlapping shift on %s from %s to %s.",
                    employee.getName(),
                    shift.getShiftDate(),
                    existingShift.getStartTime(),
                    existingShift.getEndTime()
            ));
        }

        // 5. Create roster assignment
        Roster roster = Roster.builder()
                .employee(employee)
                .shift(shift)
                .status(RosterStatus.ASSIGNED)
                .assignedAt(LocalDateTime.now())
                .build();

        Roster saved = rosterRepository.save(roster);
        return mapToResponse(saved);
    }

    @Transactional
    public void deleteRoster(Long id) {
        Roster roster = rosterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Roster entry not found with id: " + id));
        rosterRepository.delete(roster);
    }

    public RosterResponse mapToResponse(Roster roster) {
        return RosterResponse.builder()
                .id(roster.getId())
                .employee(employeeService.mapToResponse(roster.getEmployee()))
                .shift(shiftService.mapToResponse(roster.getShift()))
                .status(roster.getStatus())
                .assignedAt(roster.getAssignedAt())
                .build();
    }
}
