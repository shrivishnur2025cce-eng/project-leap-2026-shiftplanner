package com.shiftplanner.entity;

public enum RosterStatus {
    ASSIGNED,
    SWAPPED,
    CANCELLED
}
