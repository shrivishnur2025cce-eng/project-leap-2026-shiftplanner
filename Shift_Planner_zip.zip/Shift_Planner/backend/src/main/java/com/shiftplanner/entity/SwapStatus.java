package com.shiftplanner.entity;

public enum SwapStatus {
    PENDING_COLLEAGUE,
    COLLEAGUE_ACCEPTED,
    COLLEAGUE_DECLINED,
    MANAGER_APPROVED,
    MANAGER_REJECTED,
    COMPLETED
}
