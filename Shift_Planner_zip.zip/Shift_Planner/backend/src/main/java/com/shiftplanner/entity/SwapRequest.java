package com.shiftplanner.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "swap_requests")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SwapRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Requester employee is required")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "requester_id", nullable = false)
    private Employee requester;

    @NotNull(message = "Target employee is required")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "target_employee_id", nullable = false)
    private Employee targetEmployee;

    @NotNull(message = "Roster entry is required")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "roster_id", nullable = false)
    private Roster roster;

    @Column(name = "reason")
    private String reason;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private SwapStatus status;

    @Column(name = "requested_at", nullable = false)
    private LocalDateTime requestedAt;

    @Column(name = "colleague_responded_at")
    private LocalDateTime colleagueRespondedAt;

    @Column(name = "manager_approved_at")
    private LocalDateTime managerApprovedAt;

    @PrePersist
    protected void onCreate() {
        if (requestedAt == null) {
            requestedAt = LocalDateTime.now();
        }
        if (status == null) {
            status = SwapStatus.PENDING_COLLEAGUE;
        }
    }
}
