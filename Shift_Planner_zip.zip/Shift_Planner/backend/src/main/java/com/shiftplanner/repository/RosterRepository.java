package com.shiftplanner.repository;

import com.shiftplanner.entity.Roster;
import com.shiftplanner.entity.RosterStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface RosterRepository extends JpaRepository<Roster, Long> {

    List<Roster> findByShiftShiftDate(LocalDate shiftDate);

    List<Roster> findByEmployeeId(Long employeeId);

    Optional<Roster> findByEmployeeIdAndShiftIdAndStatusNot(Long employeeId, Long shiftId, RosterStatus status);

    @Query("SELECT r FROM Roster r WHERE r.employee.id = :employeeId " +
           "AND r.shift.shiftDate = :shiftDate " +
           "AND r.status != 'CANCELLED' " +
           "AND (r.shift.startTime < :endTime AND r.shift.endTime > :startTime)")
    List<Roster> findOverlappingRosters(
            @Param("employeeId") Long employeeId,
            @Param("shiftDate") LocalDate shiftDate,
            @Param("startTime") LocalTime startTime,
            @Param("endTime") LocalTime endTime
    );

    @Query("SELECT r FROM Roster r WHERE r.employee.id = :employeeId " +
           "AND r.shift.shiftDate = :shiftDate " +
           "AND r.status != 'CANCELLED' " +
           "AND r.id != :excludedRosterId " +
           "AND (r.shift.startTime < :endTime AND r.shift.endTime > :startTime)")
    List<Roster> findOverlappingRostersExcludingRoster(
            @Param("employeeId") Long employeeId,
            @Param("shiftDate") LocalDate shiftDate,
            @Param("startTime") LocalTime startTime,
            @Param("endTime") LocalTime endTime,
            @Param("excludedRosterId") Long excludedRosterId
    );
}
