package com.shiftplanner.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("ShiftPlanner REST API Documentation")
                        .version("1.0.0")
                        .description("API specifications for Employee Shift Roster Management and Shift Swap Requests System.")
                        .contact(new Contact()
                                .name("ShiftPlanner Development Team")
                                .email("admin@shiftplanner.com")));
    }
}
