package com.shiftplanner.dto;

import com.shiftplanner.entity.RosterStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RosterResponse {
    private Long id;
    private EmployeeResponse employee;
    private ShiftResponse shift;
    private RosterStatus status;
    private LocalDateTime assignedAt;
}
