package com.shiftplanner.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreateSwapRequest {

    @NotNull(message = "Requester ID is required")
    private Long requesterId;

    @NotNull(message = "Target employee ID is required")
    private Long targetEmployeeId;

    @NotNull(message = "Roster ID is required")
    private Long rosterId;

    private String reason;
}
