package com.shiftplanner.service;

import com.shiftplanner.dto.CreateSwapRequest;
import com.shiftplanner.dto.SwapResponse;
import com.shiftplanner.entity.*;
import com.shiftplanner.exception.InvalidStatusTransitionException;
import com.shiftplanner.exception.InvalidSwapException;
import com.shiftplanner.exception.ResourceNotFoundException;
import com.shiftplanner.exception.ShiftOverlapException;
import com.shiftplanner.exception.UnauthorizedActionException;
import com.shiftplanner.repository.EmployeeRepository;
import com.shiftplanner.repository.RosterRepository;
import com.shiftplanner.repository.SwapRequestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SwapRequestService {

    private final SwapRequestRepository swapRequestRepository;
    private final EmployeeRepository employeeRepository;
    private final RosterRepository rosterRepository;
    private final EmployeeService employeeService;
    private final RosterService rosterService;

    @Transactional(readOnly = true)
    public List<SwapResponse> getAllSwapRequests() {
        return swapRequestRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public SwapResponse getSwapRequestById(Long id) {
        SwapRequest request = swapRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Swap request not found with id: " + id));
        return mapToResponse(request);
    }

    @Transactional(readOnly = true)
    public List<SwapResponse> getSwapRequestsByEmployee(Long employeeId) {
        return swapRequestRepository.findByEmployeeId(employeeId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public SwapResponse createSwapRequest(CreateSwapRequest requestDto) {
        // 1. Validate requester exists & active
        Employee requester = employeeRepository.findById(requestDto.getRequesterId())
                .orElseThrow(() -> new ResourceNotFoundException("Requester employee not found with id: " + requestDto.getRequesterId()));
        if (!requester.isActive()) {
            throw new InvalidSwapException("Requester employee is inactive: " + requester.getName());
        }

        // 2. Validate target employee exists & active
        Employee targetEmployee = employeeRepository.findById(requestDto.getTargetEmployeeId())
                .orElseThrow(() -> new ResourceNotFoundException("Target employee not found with id: " + requestDto.getTargetEmployeeId()));
        if (!targetEmployee.isActive()) {
            throw new InvalidSwapException("Target employee is inactive: " + targetEmployee.getName());
        }

        // 3. Requester cannot be target employee
        if (requester.getId().equals(targetEmployee.getId())) {
            throw new InvalidSwapException("Requester and target employee cannot be the same person");
        }

        // 4. Validate roster exists & belongs to target employee
        Roster roster = rosterRepository.findById(requestDto.getRosterId())
                .orElseThrow(() -> new ResourceNotFoundException("Roster entry not found with id: " + requestDto.getRosterId()));

        if (!roster.getEmployee().getId().equals(targetEmployee.getId())) {
            throw new InvalidSwapException(String.format(
                    "Roster shift '%s' does not belong to target employee %s",
                    roster.getShift().getShiftName(),
                    targetEmployee.getName()
            ));
        }

        if (roster.getStatus() == RosterStatus.CANCELLED) {
            throw new InvalidSwapException("Cannot request swap for a cancelled roster entry");
        }

        // 5. Check if there is already an active swap request for this roster entry
        List<SwapRequest> activeRequests = swapRequestRepository.findByRosterIdAndStatusIn(
                roster.getId(),
                Arrays.asList(SwapStatus.PENDING_COLLEAGUE, SwapStatus.COLLEAGUE_ACCEPTED)
        );
        if (!activeRequests.isEmpty()) {
            throw new InvalidSwapException("An active swap request already exists for this roster assignment");
        }

        // 6. Validate that taking over this shift will not create an overlap for requester
        validateSwapDoesNotCreateOverlap(requester, roster.getShift());

        // 7. Create SwapRequest entity with initial PENDING_COLLEAGUE status
        SwapRequest swapRequest = SwapRequest.builder()
                .requester(requester)
                .targetEmployee(targetEmployee)
                .roster(roster)
                .reason(requestDto.getReason())
                .status(SwapStatus.PENDING_COLLEAGUE)
                .requestedAt(LocalDateTime.now())
                .build();

        SwapRequest saved = swapRequestRepository.save(swapRequest);
        return mapToResponse(saved);
    }

    @Transactional
    public SwapResponse acceptByColleague(Long id, Long colleagueId) {
        SwapRequest swapRequest = swapRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Swap request not found with id: " + id));

        // Only target employee can accept
        if (colleagueId != null && !swapRequest.getTargetEmployee().getId().equals(colleagueId)) {
            throw new UnauthorizedActionException("Only the target colleague (" + swapRequest.getTargetEmployee().getName() + ") can accept this request");
        }

        if (swapRequest.getStatus() != SwapStatus.PENDING_COLLEAGUE) {
            throw new InvalidStatusTransitionException(
                    "Cannot accept swap request in status: " + swapRequest.getStatus() + ". Expected status: PENDING_COLLEAGUE"
            );
        }

        swapRequest.setStatus(SwapStatus.COLLEAGUE_ACCEPTED);
        swapRequest.setColleagueRespondedAt(LocalDateTime.now());

        // Roster table remains UNCHANGED at this point!
        SwapRequest updated = swapRequestRepository.save(swapRequest);
        return mapToResponse(updated);
    }

    @Transactional
    public SwapResponse declineByColleague(Long id, Long colleagueId) {
        SwapRequest swapRequest = swapRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Swap request not found with id: " + id));

        // Only target employee can decline
        if (colleagueId != null && !swapRequest.getTargetEmployee().getId().equals(colleagueId)) {
            throw new UnauthorizedActionException("Only the target colleague (" + swapRequest.getTargetEmployee().getName() + ") can decline this request");
        }

        if (swapRequest.getStatus() != SwapStatus.PENDING_COLLEAGUE) {
            throw new InvalidStatusTransitionException(
                    "Cannot decline swap request in status: " + swapRequest.getStatus() + ". Expected status: PENDING_COLLEAGUE"
            );
        }

        swapRequest.setStatus(SwapStatus.COLLEAGUE_DECLINED);
        swapRequest.setColleagueRespondedAt(LocalDateTime.now());

        SwapRequest updated = swapRequestRepository.save(swapRequest);
        return mapToResponse(updated);
    }

    @Transactional
    public SwapResponse approveByManager(Long id, Long managerId) {
        SwapRequest swapRequest = swapRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Swap request not found with id: " + id));

        if (managerId != null) {
            Employee manager = employeeRepository.findById(managerId)
                    .orElseThrow(() -> new ResourceNotFoundException("Manager employee not found with id: " + managerId));
            if (manager.getRole() != EmployeeRole.MANAGER) {
                throw new UnauthorizedActionException("Only users with MANAGER role can approve swap requests");
            }
        }

        if (swapRequest.getStatus() != SwapStatus.COLLEAGUE_ACCEPTED) {
            throw new InvalidStatusTransitionException(
                    "Cannot approve swap request in status: " + swapRequest.getStatus() + ". Expected status: COLLEAGUE_ACCEPTED"
            );
        }

        // Re-validate overlap before final approval to ensure schedule state is still valid
        validateSwapDoesNotCreateOverlap(swapRequest.getRequester(), swapRequest.getRoster().getShift());

        // Apply roster swap: update assigned employee to requester and status to SWAPPED
        Roster roster = swapRequest.getRoster();
        roster.setEmployee(swapRequest.getRequester());
        roster.setStatus(RosterStatus.SWAPPED);
        rosterRepository.save(roster);

        // Update swap request status to MANAGER_APPROVED and then COMPLETED
        swapRequest.setStatus(SwapStatus.COMPLETED);
        swapRequest.setManagerApprovedAt(LocalDateTime.now());

        SwapRequest updated = swapRequestRepository.save(swapRequest);
        return mapToResponse(updated);
    }

    @Transactional
    public SwapResponse rejectByManager(Long id, Long managerId) {
        SwapRequest swapRequest = swapRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Swap request not found with id: " + id));

        if (managerId != null) {
            Employee manager = employeeRepository.findById(managerId)
                    .orElseThrow(() -> new ResourceNotFoundException("Manager employee not found with id: " + managerId));
            if (manager.getRole() != EmployeeRole.MANAGER) {
                throw new UnauthorizedActionException("Only users with MANAGER role can reject swap requests");
            }
        }

        if (swapRequest.getStatus() != SwapStatus.COLLEAGUE_ACCEPTED) {
            throw new InvalidStatusTransitionException(
                    "Cannot reject swap request in status: " + swapRequest.getStatus() + ". Expected status: COLLEAGUE_ACCEPTED"
            );
        }

        swapRequest.setStatus(SwapStatus.MANAGER_REJECTED);
        swapRequest.setManagerApprovedAt(LocalDateTime.now());

        SwapRequest updated = swapRequestRepository.save(swapRequest);
        return mapToResponse(updated);
    }

    public void validateSwapDoesNotCreateOverlap(Employee requester, Shift targetShift) {
        List<Roster> overlapping = rosterRepository.findOverlappingRosters(
                requester.getId(),
                targetShift.getShiftDate(),
                targetShift.getStartTime(),
                targetShift.getEndTime()
        );

        if (!overlapping.isEmpty()) {
            Roster existing = overlapping.get(0);
            throw new ShiftOverlapException(String.format(
                    "Swap rejected: Employee %s already has an overlapping shift on %s from %s to %s.",
                    requester.getName(),
                    targetShift.getShiftDate(),
                    existing.getShift().getStartTime(),
                    existing.getShift().getEndTime()
            ));
        }
    }

    public SwapResponse mapToResponse(SwapRequest swapRequest) {
        return SwapResponse.builder()
                .id(swapRequest.getId())
                .requester(employeeService.mapToResponse(swapRequest.getRequester()))
                .targetEmployee(employeeService.mapToResponse(swapRequest.getTargetEmployee()))
                .roster(rosterService.mapToResponse(swapRequest.getRoster()))
                .reason(swapRequest.getReason())
                .status(swapRequest.getStatus())
                .requestedAt(swapRequest.getRequestedAt())
                .colleagueRespondedAt(swapRequest.getColleagueRespondedAt())
                .managerApprovedAt(swapRequest.getManagerApprovedAt())
                .build();
    }
}
