package com.shiftplanner.controller;

import com.shiftplanner.dto.AssignRosterRequest;
import com.shiftplanner.dto.RosterResponse;
import com.shiftplanner.service.RosterService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/roster")
@RequiredArgsConstructor
@Tag(name = "Roster Controller", description = "Endpoints for managing roster shift assignments")
public class RosterController {

    private final RosterService rosterService;

    @GetMapping
    @Operation(summary = "Get all roster assignments")
    public ResponseEntity<List<RosterResponse>> getAllRosters(
            @RequestParam(required = false) Long employeeId) {
        if (employeeId != null) {
            return ResponseEntity.ok(rosterService.getRostersByEmployeeId(employeeId));
        }
        return ResponseEntity.ok(rosterService.getAllRosters());
    }

    @GetMapping("/date/{date}")
    @Operation(summary = "Get roster assignments for a specific date")
    public ResponseEntity<List<RosterResponse>> getRostersByDate(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(rosterService.getRostersByDate(date));
    }

    @PostMapping("/assign")
    @Operation(summary = "Assign an employee to a shift (Checks for shift overlaps)")
    public ResponseEntity<RosterResponse> assignRoster(@Valid @RequestBody AssignRosterRequest request) {
        RosterResponse assigned = rosterService.assignRoster(request);
        return new ResponseEntity<>(assigned, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Remove a roster assignment")
    public ResponseEntity<Void> deleteRoster(@PathVariable Long id) {
        rosterService.deleteRoster(id);
        return ResponseEntity.noContent().build();
    }
}
