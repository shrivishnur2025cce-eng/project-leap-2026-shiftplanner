package com.shiftplanner.service;

import com.shiftplanner.dto.CreateShiftRequest;
import com.shiftplanner.dto.ShiftResponse;
import com.shiftplanner.entity.Shift;
import com.shiftplanner.exception.InvalidSwapException;
import com.shiftplanner.exception.ResourceNotFoundException;
import com.shiftplanner.repository.ShiftRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ShiftService {

    private final ShiftRepository shiftRepository;

    @Transactional(readOnly = true)
    public List<ShiftResponse> getAllShifts() {
        return shiftRepository.findAll().stream()
                .map(this::mapToResponse)
        .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ShiftResponse getShiftById(Long id) {
        Shift shift = shiftRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shift not found with id: " + id));
        return mapToResponse(shift);
    }

    @Transactional(readOnly = true)
    public List<ShiftResponse> getShiftsByDate(LocalDate date) {
        return shiftRepository.findByShiftDate(date).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public ShiftResponse createShift(CreateShiftRequest request) {
        if (!request.getEndTime().isAfter(request.getStartTime())) {
            throw new InvalidSwapException("Shift end time must be after start time");
        }

        Shift shift = Shift.builder()
                .shiftName(request.getShiftName())
                .shiftDate(request.getShiftDate())
                .startTime(request.getStartTime())
                .endTime(request.getEndTime())
                .description(request.getDescription())
                .build();

        Shift saved = shiftRepository.save(shift);
        return mapToResponse(saved);
    }

    @Transactional
    public ShiftResponse updateShift(Long id, CreateShiftRequest request) {
        Shift shift = shiftRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shift not found with id: " + id));

        if (!request.getEndTime().isAfter(request.getStartTime())) {
            throw new InvalidSwapException("Shift end time must be after start time");
        }

        shift.setShiftName(request.getShiftName());
        shift.setShiftDate(request.getShiftDate());
        shift.setStartTime(request.getStartTime());
        shift.setEndTime(request.getEndTime());
        shift.setDescription(request.getDescription());

        Shift updated = shiftRepository.save(shift);
        return mapToResponse(updated);
    }

    @Transactional
    public void deleteShift(Long id) {
        if (!shiftRepository.existsById(id)) {
            throw new ResourceNotFoundException("Shift not found with id: " + id);
        }
        shiftRepository.deleteById(id);
    }

    public ShiftResponse mapToResponse(Shift shift) {
        return ShiftResponse.builder()
                .id(shift.getId())
                .shiftName(shift.getShiftName())
                .shiftDate(shift.getShiftDate())
                .startTime(shift.getStartTime())
                .endTime(shift.getEndTime())
                .description(shift.getDescription())
                .build();
    }
}
