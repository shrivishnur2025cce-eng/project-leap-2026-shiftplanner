package com.shiftplanner.entity;

public enum EmployeeRole {
    EMPLOYEE,
    MANAGER
}
