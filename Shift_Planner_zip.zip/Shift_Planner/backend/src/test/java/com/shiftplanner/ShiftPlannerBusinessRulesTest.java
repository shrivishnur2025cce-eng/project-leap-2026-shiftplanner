package com.shiftplanner;

import com.shiftplanner.dto.*;
import com.shiftplanner.entity.*;
import com.shiftplanner.exception.*;
import com.shiftplanner.repository.*;
import com.shiftplanner.service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
@ActiveProfiles("test")
public class ShiftPlannerBusinessRulesTest {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private ShiftService shiftService;

    @Autowired
    private RosterService rosterService;

    @Autowired
    private SwapRequestService swapRequestService;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private ShiftRepository shiftRepository;

    @Autowired
    private RosterRepository rosterRepository;

    @Autowired
    private SwapRequestRepository swapRequestRepository;

    private EmployeeResponse arun;
    private EmployeeResponse bala;
    private EmployeeResponse managerKumar;
    private ShiftResponse mondayMorningShift;
    private ShiftResponse mondayAfternoonShift;

    @BeforeEach
    void setUp() {
        // Clear repositories before each test
        swapRequestRepository.deleteAll();
        rosterRepository.deleteAll();
        shiftRepository.deleteAll();
        employeeRepository.deleteAll();

        // 1. Create Employees
        arun = employeeService.createEmployee(CreateEmployeeRequest.builder()
                .employeeCode("EMP001")
                .name("Arun")
                .email("arun@example.com")
                .phone("9876543210")
                .role(EmployeeRole.EMPLOYEE)
                .active(true)
                .build());

        bala = employeeService.createEmployee(CreateEmployeeRequest.builder()
                .employeeCode("EMP002")
                .name("Bala")
                .email("bala@example.com")
                .phone("9876543211")
                .role(EmployeeRole.EMPLOYEE)
                .active(true)
                .build());

        managerKumar = employeeService.createEmployee(CreateEmployeeRequest.builder()
                .employeeCode("MGR001")
                .name("Manager Kumar")
                .email("kumar@example.com")
                .phone("9876543212")
                .role(EmployeeRole.MANAGER)
                .active(true)
                .build());

        // 2. Create Shifts
        mondayMorningShift = shiftService.createShift(CreateShiftRequest.builder()
                .shiftName("Monday Morning Shift")
                .shiftDate(LocalDate.of(2026, 10, 5))
                .startTime(LocalTime.of(9, 0))
                .endTime(LocalTime.of(13, 0))
                .description("Morning assembly shift")
                .build());

        mondayAfternoonShift = shiftService.createShift(CreateShiftRequest.builder()
                .shiftName("Monday Afternoon Shift")
                .shiftDate(LocalDate.of(2026, 10, 5))
                .startTime(LocalTime.of(14, 0))
                .endTime(LocalTime.of(18, 0))
                .description("Afternoon assembly shift")
                .build());
    }

    @Test
    @DisplayName("1. Test Employee Creation")
    void testEmployeeCreation() {
        assertNotNull(arun.getId());
        assertEquals("Arun", arun.getName());
        assertEquals(EmployeeRole.EMPLOYEE, arun.getRole());
    }

    @Test
    @DisplayName("2. Test Shift Creation")
    void testShiftCreation() {
        assertNotNull(mondayMorningShift.getId());
        assertEquals(LocalTime.of(9, 0), mondayMorningShift.getStartTime());
        assertEquals(LocalTime.of(13, 0), mondayMorningShift.getEndTime());
    }

    @Test
    @DisplayName("3. Test Valid Roster Assignment")
    void testRosterAssignment() {
        RosterResponse roster = rosterService.assignRoster(AssignRosterRequest.builder()
                .employeeId(arun.getId())
                .shiftId(mondayMorningShift.getId())
                .build());

        assertNotNull(roster.getId());
        assertEquals(arun.getId(), roster.getEmployee().getId());
        assertEquals(RosterStatus.ASSIGNED, roster.getStatus());
    }

    @Test
    @DisplayName("4. Test Overlapping Shift Rejection")
    void testOverlappingShiftRejection() {
        // Assign Arun to 09:00 - 13:00
        rosterService.assignRoster(AssignRosterRequest.builder()
                .employeeId(arun.getId())
                .shiftId(mondayMorningShift.getId())
                .build());

        // Create an overlapping shift: 11:00 - 15:00 on same date
        ShiftResponse overlappingShift = shiftService.createShift(CreateShiftRequest.builder()
                .shiftName("Overlapping Midday Shift")
                .shiftDate(LocalDate.of(2026, 10, 5))
                .startTime(LocalTime.of(11, 0))
                .endTime(LocalTime.of(15, 0))
                .description("Overlapping shift")
                .build());

        // Attempt to assign Arun to overlapping shift -> Expect ShiftOverlapException
        ShiftOverlapException exception = assertThrows(ShiftOverlapException.class, () -> {
            rosterService.assignRoster(AssignRosterRequest.builder()
                    .employeeId(arun.getId())
                    .shiftId(overlappingShift.getId())
                    .build());
        });

        assertTrue(exception.getMessage().contains("already has an overlapping shift"));
    }

    @Test
    @DisplayName("5. Test Swap Request Creation (Status PENDING_COLLEAGUE)")
    void testSwapRequestCreation() {
        // Assign Bala to Monday Afternoon Shift
        RosterResponse balaRoster = rosterService.assignRoster(AssignRosterRequest.builder()
                .employeeId(bala.getId())
                .shiftId(mondayAfternoonShift.getId())
                .build());

        // Arun requests to swap with Bala's roster entry
        SwapResponse swap = swapRequestService.createSwapRequest(CreateSwapRequest.builder()
                .requesterId(arun.getId())
                .targetEmployeeId(bala.getId())
                .rosterId(balaRoster.getId())
                .reason("Medical appointment in afternoon")
                .build());

        assertNotNull(swap.getId());
        assertEquals(SwapStatus.PENDING_COLLEAGUE, swap.getStatus());
        assertEquals(arun.getId(), swap.getRequester().getId());
        assertEquals(bala.getId(), swap.getTargetEmployee().getId());
    }

    @Test
    @DisplayName("6. Test Colleague Acceptance (Status COLLEAGUE_ACCEPTED)")
    void testColleagueAcceptance() {
        RosterResponse balaRoster = rosterService.assignRoster(AssignRosterRequest.builder()
                .employeeId(bala.getId())
                .shiftId(mondayAfternoonShift.getId())
                .build());

        SwapResponse swap = swapRequestService.createSwapRequest(CreateSwapRequest.builder()
                .requesterId(arun.getId())
                .targetEmployeeId(bala.getId())
                .rosterId(balaRoster.getId())
                .reason("Personal request")
                .build());

        // Bala accepts
        SwapResponse accepted = swapRequestService.acceptByColleague(swap.getId(), bala.getId());

        assertEquals(SwapStatus.COLLEAGUE_ACCEPTED, accepted.getStatus());
        assertNotNull(accepted.getColleagueRespondedAt());

        // Verify Roster table STILL has Bala assigned (UNCHANGED)
        Roster currentRoster = rosterRepository.findById(balaRoster.getId()).orElseThrow();
        assertEquals(bala.getId(), currentRoster.getEmployee().getId());
    }

    @Test
    @DisplayName("7. Test Colleague Rejection (Status COLLEAGUE_DECLINED)")
    void testColleagueRejection() {
        RosterResponse balaRoster = rosterService.assignRoster(AssignRosterRequest.builder()
                .employeeId(bala.getId())
                .shiftId(mondayAfternoonShift.getId())
                .build());

        SwapResponse swap = swapRequestService.createSwapRequest(CreateSwapRequest.builder()
                .requesterId(arun.getId())
                .targetEmployeeId(bala.getId())
                .rosterId(balaRoster.getId())
                .reason("Need swap")
                .build());

        // Bala declines
        SwapResponse declined = swapRequestService.declineByColleague(swap.getId(), bala.getId());

        assertEquals(SwapStatus.COLLEAGUE_DECLINED, declined.getStatus());
    }

    @Test
    @DisplayName("8. Test Manager Approval & Roster Swap Execution")
    void testManagerApproval() {
        RosterResponse balaRoster = rosterService.assignRoster(AssignRosterRequest.builder()
                .employeeId(bala.getId())
                .shiftId(mondayAfternoonShift.getId())
                .build());

        SwapResponse swap = swapRequestService.createSwapRequest(CreateSwapRequest.builder()
                .requesterId(arun.getId())
                .targetEmployeeId(bala.getId())
                .rosterId(balaRoster.getId())
                .reason("Emergency")
                .build());

        // Step 1: Bala accepts
        swapRequestService.acceptByColleague(swap.getId(), bala.getId());

        // Step 2: Manager approves
        SwapResponse approved = swapRequestService.approveByManager(swap.getId(), managerKumar.getId());

        assertEquals(SwapStatus.COMPLETED, approved.getStatus());
        assertNotNull(approved.getManagerApprovedAt());

        // Verify Roster entry is now updated to Arun!
        Roster updatedRoster = rosterRepository.findById(balaRoster.getId()).orElseThrow();
        assertEquals(arun.getId(), updatedRoster.getEmployee().getId());
        assertEquals(RosterStatus.SWAPPED, updatedRoster.getStatus());
    }

    @Test
    @DisplayName("9. Test Manager Rejection")
    void testManagerRejection() {
        RosterResponse balaRoster = rosterService.assignRoster(AssignRosterRequest.builder()
                .employeeId(bala.getId())
                .shiftId(mondayAfternoonShift.getId())
                .build());

        SwapResponse swap = swapRequestService.createSwapRequest(CreateSwapRequest.builder()
                .requesterId(arun.getId())
                .targetEmployeeId(bala.getId())
                .rosterId(balaRoster.getId())
                .reason("Vacation")
                .build());

        swapRequestService.acceptByColleague(swap.getId(), bala.getId());

        // Manager rejects
        SwapResponse rejected = swapRequestService.rejectByManager(swap.getId(), managerKumar.getId());

        assertEquals(SwapStatus.MANAGER_REJECTED, rejected.getStatus());

        // Roster remains assigned to Bala
        Roster roster = rosterRepository.findById(balaRoster.getId()).orElseThrow();
        assertEquals(bala.getId(), roster.getEmployee().getId());
    }

    @Test
    @DisplayName("10. Verify Roster changes ONLY after manager approval")
    void testRosterChangesOnlyAfterManagerApproval() {
        RosterResponse balaRoster = rosterService.assignRoster(AssignRosterRequest.builder()
                .employeeId(bala.getId())
                .shiftId(mondayAfternoonShift.getId())
                .build());

        SwapResponse swap = swapRequestService.createSwapRequest(CreateSwapRequest.builder()
                .requesterId(arun.getId())
                .targetEmployeeId(bala.getId())
                .rosterId(balaRoster.getId())
                .reason("Need shift change")
                .build());

        // Step 1: Pending colleague -> Roster employee is Bala
        assertEquals(bala.getId(), rosterRepository.findById(balaRoster.getId()).orElseThrow().getEmployee().getId());

        // Step 2: Colleague accepts -> Roster employee STILL Bala
        swapRequestService.acceptByColleague(swap.getId(), bala.getId());
        assertEquals(bala.getId(), rosterRepository.findById(balaRoster.getId()).orElseThrow().getEmployee().getId());

        // Step 3: Manager approves -> Roster employee NOW Arun
        swapRequestService.approveByManager(swap.getId(), managerKumar.getId());
        assertEquals(arun.getId(), rosterRepository.findById(balaRoster.getId()).orElseThrow().getEmployee().getId());
    }

    @Test
    @DisplayName("11. Test Invalid Status Transition Exception")
    void testInvalidStatusTransition() {
        RosterResponse balaRoster = rosterService.assignRoster(AssignRosterRequest.builder()
                .employeeId(bala.getId())
                .shiftId(mondayAfternoonShift.getId())
                .build());

        SwapResponse swap = swapRequestService.createSwapRequest(CreateSwapRequest.builder()
                .requesterId(arun.getId())
                .targetEmployeeId(bala.getId())
                .rosterId(balaRoster.getId())
                .reason("Testing transition")
                .build());

        // Try to approve directly from PENDING_COLLEAGUE without colleague acceptance -> Expect exception
        assertThrows(InvalidStatusTransitionException.class, () -> {
            swapRequestService.approveByManager(swap.getId(), managerKumar.getId());
        });
    }

    @Test
    @DisplayName("12. Test Non-existing Employee Exception")
    void testNonExistingEmployee() {
        assertThrows(ResourceNotFoundException.class, () -> {
            employeeService.getEmployeeById(99999L);
        });
    }

    @Test
    @DisplayName("13. Test Non-existing Shift Exception")
    void testNonExistingShift() {
        assertThrows(ResourceNotFoundException.class, () -> {
            shiftService.getShiftById(99999L);
        });
    }
}
